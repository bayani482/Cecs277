class Contact:
    """creates a contact object .
    Attributes:
    fn (str): first name.
    ln (str): last name.
    ph (str): phone.
    addr (str): address.
    city (str): city.
    zip (str): zip.
    """
    def __init__(self, fn, ln, ph, addr, city, zip):
        """Initializes the contact information.
        Args:
            fn (str): first name set from argument.
            ln (str): last name set from argument.
            ph (str): phone set from argument.
            addr (str): address set from argument.
            city (str): city set from argument.
            zip (str): zip set from argument.
        """
        self.fn = fn
        self.ln = ln
        self.ph = ph
        self.addr = addr
        self.city = city
        self.zip = zip

    def __lt__(self,other):
        """
        Compares two contacts for sorting.
        Args:
            other (Contact): The other contact to compare against.
        Returns:
            bool: True if this contact is less than the other contact, False otherwise."""
        if self.ln != other.ln:
            return self.ln < other.ln
        return self.fn < other.fn
            
    def __str__(self):
        """
        Returns the contact as a formatted string.
        Returns:
            str: A string with contact's details.
        """
        return f"{self.fn} {self.ln}\n{self.ph}\n{self.addr}\n{self.city}\n{self.zip}\n"
    
    def __repr__(self):
        """
        Returns a string representation of contact for writing into file
        Returns:
            str: A comma-separated string of contact's details.
        """

        return f"{self.fn},{self.ln},{self.ph},{self.addr},{self.city},{self.zip}"
